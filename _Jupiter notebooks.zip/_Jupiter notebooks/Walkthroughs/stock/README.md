This folder contains code and files for a stock walkthrough project.

To run it locally, make sure to do the following:

* Create a python virtual environment
* `pip install -r requirements.txt`
* Open StockProject.ipynb in JupyerLab